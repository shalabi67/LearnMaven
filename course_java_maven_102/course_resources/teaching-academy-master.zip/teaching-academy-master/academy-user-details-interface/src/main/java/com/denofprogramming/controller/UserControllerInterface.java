package com.denofprogramming.controller;

import com.denofprogramming.model.User;

public interface UserControllerInterface extends ControllerInterface<User>{

}
