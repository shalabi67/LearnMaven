package com.denofprogramming.repository;

import com.denofprogramming.model.Course;

public interface CourseRepositoryInterface extends RepositoryInterface<Course>{

}
