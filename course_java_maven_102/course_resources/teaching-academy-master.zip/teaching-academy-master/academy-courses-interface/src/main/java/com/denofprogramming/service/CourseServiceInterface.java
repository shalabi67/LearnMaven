package com.denofprogramming.service;

import com.denofprogramming.model.Course;

public interface CourseServiceInterface extends ServiceInterface<Course>{

	
}
