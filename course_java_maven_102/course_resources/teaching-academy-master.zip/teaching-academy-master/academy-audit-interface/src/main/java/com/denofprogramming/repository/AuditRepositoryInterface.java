package com.denofprogramming.repository;

import com.denofprogramming.model.AuditDetail;

public interface AuditRepositoryInterface extends RepositoryInterface<AuditDetail>{

}
