package com.denofprogramming.service;

import com.denofprogramming.model.Registration;

public interface RegistrationServiceInterface extends ServiceInterface<Registration>{

	
}
