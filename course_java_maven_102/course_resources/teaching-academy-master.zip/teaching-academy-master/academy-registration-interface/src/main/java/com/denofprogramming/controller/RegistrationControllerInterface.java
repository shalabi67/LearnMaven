package com.denofprogramming.controller;

import com.denofprogramming.model.Registration;

public interface RegistrationControllerInterface extends ControllerInterface<Registration>{

}
