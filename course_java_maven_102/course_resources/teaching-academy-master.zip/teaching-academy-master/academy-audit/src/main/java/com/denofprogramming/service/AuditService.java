package com.denofprogramming.service;

import com.denofprogramming.model.AuditDetail;

public class AuditService implements AuditServiceInterface{

	@Override
	public AuditDetail read(AuditDetail domainObject) {
		return null;
	}

	@Override
	public AuditDetail update(AuditDetail domainObject) {
		return null;
	}

}
