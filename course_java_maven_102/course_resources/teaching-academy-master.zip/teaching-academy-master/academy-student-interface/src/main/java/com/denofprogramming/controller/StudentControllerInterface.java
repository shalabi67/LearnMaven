package com.denofprogramming.controller;

import com.denofprogramming.model.Student;

public interface StudentControllerInterface extends ControllerInterface<Student>{

}
