package com.denofprogramming.service;

import com.denofprogramming.model.Student;

public interface StudentServiceInterface extends ServiceInterface<Student>{

	
}
