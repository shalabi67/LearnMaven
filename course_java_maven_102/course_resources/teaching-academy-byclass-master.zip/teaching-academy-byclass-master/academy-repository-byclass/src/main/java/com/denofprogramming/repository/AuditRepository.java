package com.denofprogramming.repository;

public class AuditRepository {

}
