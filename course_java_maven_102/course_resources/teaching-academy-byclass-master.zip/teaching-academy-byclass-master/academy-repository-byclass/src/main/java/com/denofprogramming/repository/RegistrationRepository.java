package com.denofprogramming.repository;

public class RegistrationRepository implements RepositoryInterface {

}
