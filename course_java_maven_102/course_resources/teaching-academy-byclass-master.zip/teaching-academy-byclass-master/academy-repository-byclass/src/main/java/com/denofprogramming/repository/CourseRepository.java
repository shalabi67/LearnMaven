package com.denofprogramming.repository;

public class CourseRepository implements RepositoryInterface {

}
