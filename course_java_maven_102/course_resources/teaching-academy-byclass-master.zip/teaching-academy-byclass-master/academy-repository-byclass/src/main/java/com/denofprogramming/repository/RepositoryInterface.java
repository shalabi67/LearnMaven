package com.denofprogramming.repository;

public interface RepositoryInterface {

}
