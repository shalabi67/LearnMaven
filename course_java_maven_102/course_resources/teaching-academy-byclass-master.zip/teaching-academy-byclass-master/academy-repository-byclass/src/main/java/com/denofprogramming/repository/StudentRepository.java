package com.denofprogramming.repository;

public class StudentRepository implements RepositoryInterface {

}
