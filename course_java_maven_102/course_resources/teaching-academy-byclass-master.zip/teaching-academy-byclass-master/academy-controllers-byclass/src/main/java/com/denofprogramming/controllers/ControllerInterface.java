package com.denofprogramming.controllers;

public interface ControllerInterface {

}
