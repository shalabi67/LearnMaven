package com.denofprogramming.controllers;

public class AuditController implements ControllerInterface {

}
