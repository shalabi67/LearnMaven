package com.denofprogramming.controllers;

public class RegistrationController implements ControllerInterface {

}
