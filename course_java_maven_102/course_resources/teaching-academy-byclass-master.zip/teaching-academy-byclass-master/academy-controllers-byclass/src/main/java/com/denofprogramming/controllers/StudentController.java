package com.denofprogramming.controllers;

public class StudentController implements ControllerInterface {

}
