package com.denofprogramming.controllers;

public class CourseController implements ControllerInterface {

}
