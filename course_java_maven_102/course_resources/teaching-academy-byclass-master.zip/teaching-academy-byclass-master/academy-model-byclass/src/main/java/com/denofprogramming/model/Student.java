package com.denofprogramming.model;

public class Student {

}
