package com.denofprogramming.model;

public class Enrollment {

}
