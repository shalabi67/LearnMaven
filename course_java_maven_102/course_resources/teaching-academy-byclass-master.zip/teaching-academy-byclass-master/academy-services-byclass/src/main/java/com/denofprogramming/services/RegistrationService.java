package com.denofprogramming.services;

public class RegistrationService implements ServiceInterface{

}
