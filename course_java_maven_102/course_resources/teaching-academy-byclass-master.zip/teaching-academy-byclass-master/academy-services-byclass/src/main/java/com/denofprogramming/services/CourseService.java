package com.denofprogramming.services;

public class CourseService implements ServiceInterface {

}
