package com.denofprogramming.services;

public interface ServiceInterface {

}
