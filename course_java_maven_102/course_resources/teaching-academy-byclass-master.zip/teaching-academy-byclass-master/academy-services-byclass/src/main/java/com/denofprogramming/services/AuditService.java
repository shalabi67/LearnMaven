package com.denofprogramming.services;

public class AuditService implements ServiceInterface {

}
