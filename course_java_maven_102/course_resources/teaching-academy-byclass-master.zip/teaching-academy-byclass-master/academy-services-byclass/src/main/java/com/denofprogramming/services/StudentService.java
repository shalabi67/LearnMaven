package com.denofprogramming.services;

public class StudentService implements ServiceInterface{

}
