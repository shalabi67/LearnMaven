/**
 * 
 */
package com.denofprogramming.random;

/**
 * @author TT
 * 
 */
public interface RandomGenerator
{

    String name();

    int generate();

}
